const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [50, 'Name cannot exceed 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      'Please enter a valid email'
    ]
  },
  // Ensure there is no username field or index in this schema
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters'],
    select: false // Don't include password in queries by default
  },
  isActive: {
    type: Boolean,
    default: true
  },
  loginOtp: {
    codeHash: {
      type: String
    },
    expiresAt: {
      type: Date
    },
    attemptCount: {
      type: Number,
      default: 0
    },
    lastRequestedAt: {
      type: Date
    }
  },
  passwordReset: {
    otpHash: {
      type: String
    },
    otpExpiresAt: {
      type: Date
    },
    otpAttemptCount: {
      type: Number,
      default: 0
    },
    resetTokenHash: {
      type: String
    },
    resetTokenExpiresAt: {
      type: Date
    }
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for better query performance (email index created automatically by unique constraint)
userSchema.index({ createdAt: -1 });

// Hash password before saving
userSchema.pre('save', async function(next) {
  // Only hash the password if it has been modified (or is new)
  if (!this.isModified('password')) return next();

  try {
    // Hash password with cost of 12
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw error;
  }
};

// Remove password from JSON output
userSchema.methods.toJSON = function() {
  const userObject = this.toObject();
  delete userObject.password;
  if (userObject.loginOtp) {
    delete userObject.loginOtp;
  }
  if (userObject.passwordReset) {
    delete userObject.passwordReset;
  }
  return userObject;
};

module.exports = mongoose.model('User', userSchema);
